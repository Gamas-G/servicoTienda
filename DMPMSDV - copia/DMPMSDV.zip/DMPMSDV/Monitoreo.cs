﻿
namespace DMPMSDV
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Banco.PD3.Persistence;
    using Banco.PD3.Persistence.Entities;
    using System.Data.SqlClient;
    using Microsoft.Web.Administration;
    using System.Net;

    public class Monitoreo
    {
        PD3Connection conn1;
        string Qry = string.Empty;
        private static log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string path = @"E:\ADN\NET64_BAZ\Certs\";
        string certificado = "baz-52bd6396-0f8d-4188-959e-4f1083bfd836.pd3";

        public bool MonitorDV()
        {
            try
            {
                log.Info(string.Format("Inicia proceso de Monitoreo de Directorios Virtuales"));

                DMPMicroservicio.csMsMetodos dllMs = new DMPMicroservicio.csMsMetodos();
                conn1 = new PD3Connection();
                conn1 = Certificater.GetPD3Connection(path, certificado);
                SqlPersister persistence = new SqlPersister(conn1);
                SqlDataReader reader = null;
                Qry = "exec spConDMPDirVirtualMtr";
                reader = persistence.ScriptToDataReader(Qry);

                if (reader.HasRows)
                {
                    string SitioWeb = "localhost";
                    using (var iis = ServerManager.OpenRemote(SitioWeb))
                    {
                        List<Site> sites = iis.Sites.ToList();

                        while (reader.Read())
                        {
                            int veces = 0;
                            bool existedv = false;
                            foreach (Site sib in sites)
                            {
                                if (sites[veces].Name == reader[1].ToString().Trim())
                                {
                                    List<VirtualDirectory> vds = sites[veces].Applications[0].VirtualDirectories.ToList();
                                    foreach (VirtualDirectory dv in vds)
                                    {
                                        if (dv.Path == ("/" + reader[6].ToString().Trim()))
                                        {
                                            existedv = true;
                                            break;
                                        }
                                    }
                                }
                                veces += 1;
                                if (existedv)
                                {
                                    veces = 0;
                                    break;
                                }
                            }

                            if (!existedv)
                            {
                                log.Info(string.Format("Se genera Hallazgo"));
                                //GeneraHallazgo(Convert.ToInt32(reader[7].ToString().Trim()), "No se encontro el Directorio Virtual " + reader[6].ToString().Trim() + " del sitio " + reader[1].ToString().Trim());
                                dllMs.GeneraHallazgo(Convert.ToInt32(reader[7].ToString().Trim()), "No se encontro el Directorio Virtual " + reader[6].ToString().Trim() + " del sitio " + reader[1].ToString().Trim(),"DV");
                            }

                        }
                    }
                }
                reader.Close();

                //ControlCheck();
                dllMs.ControlCheck("DV", Globales.WorkStation, "DV");
                log.Info(string.Format("Termina proceso de Monitoreo de Directorios Virtuales"));
                return true;

            }
            catch (Exception ex)
            {
                log.Error(string.Format("Error en MonitorDV: {0}", ex.Message));
                return false;
            }
        }

        //public void GeneraHallazgo(int param, string strDetalle)
        //{
        //    try
        //    {
        //        SqlPersister persistence = new SqlPersister(conn1);
        //        SqlDataReader readerIns = null;

        //        Qry = "exec spInsDMPMtrHallazgos " + param + ",'" + Dns.GetHostName() + "','" + strDetalle + "',2";
        //        readerIns = persistence.ScriptToDataReader(Qry);
        //        readerIns.Close();
        //    }
        //    catch (Exception ex)
        //    {
        //        log.Error(string.Format("Error en GeneraHallazgo: {0}", ex.Message));
        //    }
        //}

        public void CargaConfiguracion()
        {
            try
            {
                log.Info(string.Format("Inicia carga de Configuración"));

                DMPMicroservicio.csMsMetodos dllMs = new DMPMicroservicio.csMsMetodos();

                dllMs.CargaConfiguracion("DV");
                Globales.TipoMtrIni = dllMs.TipoMtrIni;
                Globales.HoraIniMtr = dllMs.HoraIniMtr;
                Globales.IntervaloMtr = dllMs.IntervaloMtr;
                Globales.IntervMinMtr = dllMs.IntervMinMtr;
                Globales.ToleranciaMtr = dllMs.ToleranciaMtr;                
                Globales.ipNT = dllMs.ObtenerIP();

                log.Info(string.Format("Termina carga de Configuración"));
            }
            catch (Exception ex)
            {
                log.Error(string.Format("Error en CargaConfiguracion: {0}", ex.Message));
            }
        }

        public void AgendarTarea(int Tipo, string Tarea, string Gatillo,string HoraAlter)
        {
            TareasProgramadas TareasP = new TareasProgramadas();            
            TareasP.Monitoreo(Tipo, Tarea, Gatillo, HoraAlter);
        }

        //public void ControlCheck()
        //{
        //    try
        //    {
        //        log.Info(string.Format("Inicia Check en tabla Control"));
        //        SqlPersister persistence = new SqlPersister(conn1);
        //        SqlDataReader reader = null;
        //        Qry = "exec spConDMPMtrConfigManto 2,'" + Globales.WorkStation + "'";
        //        reader = persistence.ScriptToDataReader(Qry);
        //        string CheckReport = string.Empty;
        //        string CheckFinal = string.Empty;

        //        if (reader.HasRows)
        //        {
        //            reader.Read();
        //            CheckReport = reader != null ? reader[0].ToString().Trim() : string.Empty;
        //        }
        //        reader.Close();

        //        if (CheckReport != string.Empty)
        //        {
        //            string[] LstChk = CheckReport.Split('|');
        //            foreach (string chk in LstChk)
        //            {
        //                if (chk.StartsWith("DV"))
        //                {
        //                    CheckFinal += "DV#" + DateTime.Now.ToString() + "|";
        //                }
        //                else
        //                {
        //                    CheckFinal += chk + "|";
        //                }
        //            }
        //        }
        //        else
        //        {
        //            CheckFinal = "DV#" + DateTime.Now.ToString() + "|";
        //        }

        //        CheckFinal = CheckFinal.Substring(0, CheckFinal.Length - 1);

        //        log.Info(string.Format("Se actualizara FechaReporte en Control"));
        //        Qry = "exec spUpdDMPMtrConfigManto 1,'" + CheckFinal + "','" + Globales.WorkStation + "'";
        //        reader = persistence.ScriptToDataReader(Qry);
        //        reader.Close();

        //        log.Info(string.Format("Termina Check en tabla Control"));
        //    }

        //    catch (Exception ex)
        //    {
        //        log.Error(string.Format("Error en ControlCheck: {0}", ex.Message));
        //    }
        //}

        public void InicioAlterno()
        {
            int horaini;
            int minutosini;
            int horaAct;
            int minutosAct;
            int IntervHora;

            try
            {
                log.Info(string.Format("Inicia proceso InicioAlterno"));

                //string[] tiempo = Globales.HoraIniMtr.Split(':');               
                //Int32.TryParse(tiempo[0], out horaini);
                //Int32.TryParse(tiempo[1], out minutosini);

                //horaAct = DateTime.Now.Hour;
                //minutosAct = DateTime.Now.Minute;
                //IntervHora = (Globales.IntervaloMtr / 60);

                //int HoraAlterna = horaini;
                //while (HoraAlterna <= horaAct)
                //{
                //    HoraAlterna += IntervHora;
                //}

                string HoraProg = string.Empty;
                ////HoraProg = (HoraAlterna < 10 ? "0" + HoraAlterna.ToString() : HoraAlterna.ToString()) + ":" + minutosini.ToString("00");
                DMPMicroservicio.csMsMetodos dllMs = new DMPMicroservicio.csMsMetodos();
                HoraProg = dllMs.InicioAlterno(Globales.HoraIniMtr, Globales.IntervaloMtr, "DV");

                log.Info(string.Format("Se programara tarea de Monitoreo Inicial Alterno"));
                TareasProgramadas TareasP = new TareasProgramadas();
                TareasP.Monitoreo(3, "MtrIniAlter", "triggerMtrAlter", HoraProg);

                log.Info(string.Format("Termina proceso InicioAlterno"));
            }
            catch (Exception ex)
            {
                log.Error(string.Format("Error en InicioAlterno: {0}", ex.Message));
            }
        }
    }
}

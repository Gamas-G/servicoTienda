﻿namespace DMPMSDV
{
    using System;
    using Banco.PD3.Persistence;
    using Banco.PD3.Persistence.Entities;
    using System.Data.SqlClient;
    using Microsoft.Web.Administration;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.NetworkInformation;

    class WcfDMPMonitorDV : IWcfDMPMonitorDV
    {
        PD3Connection conn1;
        string Qry = string.Empty;
        private static log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string path = @"E:\ADN\NET64_BAZ\Certs\";
        string certificado = "baz-52bd6396-0f8d-4188-959e-4f1083bfd836.pd3";

        public bool MonitorDVPorSolicitud()
        {
            try
            {
                conn1 = new PD3Connection();
                conn1 = Certificater.GetPD3Connection(path, certificado);
                SqlPersister persistence = new SqlPersister(conn1);
                SqlDataReader reader = null;
                Qry = "exec spConDMPDirVirtualMtr";
                reader = persistence.ScriptToDataReader(Qry);

                if (reader.HasRows)
                {
                    string SitioWeb = "localhost";
                    using (var iis = ServerManager.OpenRemote(SitioWeb))
                    {
                        List<Site> sites = iis.Sites.ToList();

                        while (reader.Read())
                        {
                            int veces = 0;
                            bool existedv = false;
                            foreach (Site sib in sites)
                            {
                                if (sites[veces].Name == reader[1].ToString().Trim())
                                {
                                    List<VirtualDirectory> vds = sites[veces].Applications[0].VirtualDirectories.ToList();
                                    foreach (VirtualDirectory dv in vds)
                                    {
                                        if (dv.Path == ("/" + reader[6].ToString().Trim()))
                                        {
                                            existedv = true;
                                            break;
                                        }
                                    }
                                }
                                veces += 1;
                                if (existedv)
                                {
                                    veces = 0;
                                    break;
                                }
                            }

                            if (!existedv)
                            {
                                GeneraHallazgo(Convert.ToInt32(reader[7].ToString().Trim()), "No se encontro el Directorio Virtual " + reader[6].ToString().Trim() + " del sitio " + reader[1].ToString().Trim());
                            }
                            
                        }
                    }
                }
                reader.Close();

                ControlCheck();
                return true;
            }
            catch (Exception ex)
            {
                log.Error(string.Format("Error en MonitorDVPorSolicitud: {0}", ex.Message));
                return false;
            }
        }

        private void GeneraHallazgo(int param, string strDetalle)
        {
            try
            {
                SqlPersister persistence = new SqlPersister(conn1);
                SqlDataReader readerIns = null;

                Qry = "exec spInsDMPMtrHallazgos " + param + ",'" + Dns.GetHostName() + "','" + strDetalle + "',2";
                readerIns = persistence.ScriptToDataReader(Qry);
                readerIns.Close();
            }
            catch (Exception ex)
            {
                log.Error(string.Format("Error en GeneraHallazgo Wcf: {0}", ex.Message));
            }
        }

        private void ControlCheck()
        {
            try
            {
                log.Info(string.Format("Inicia Check en tabla Control WCF"));
                SqlPersister persistence = new SqlPersister(conn1);
                SqlDataReader reader = null;
                Qry = "exec spConDMPMtrConfigManto 2,'" + Globales.WorkStation + "'";
                reader = persistence.ScriptToDataReader(Qry);
                string CheckReport = string.Empty;
                string CheckFinal = string.Empty;

                if (reader.HasRows)
                {
                    reader.Read();
                    CheckReport = reader != null ? reader[0].ToString().Trim() : string.Empty;
                }
                reader.Close();

                if (CheckReport != string.Empty)
                {
                    string[] LstChk = CheckReport.Split('|');
                    foreach (string chk in LstChk)
                    {
                        if (chk.StartsWith("DV"))
                        {
                            CheckFinal += "DV#" + DateTime.Now.ToString() + "|";
                        }
                        else
                        {
                            CheckFinal += chk + "|";
                        }
                    }
                }
                else
                {
                    CheckFinal = "DV#" + DateTime.Now.ToString() + "|";
                }

                CheckFinal = CheckFinal.Substring(0, CheckFinal.Length - 1);

                log.Info(string.Format("Se actualizara FechaReporte en Control"));
                Qry = "exec spUpdDMPMtrConfigManto 1,'" + CheckFinal + "','" + Globales.WorkStation + "'";
                reader = persistence.ScriptToDataReader(Qry);
                reader.Close();

                log.Info(string.Format("Termina Check WCF en tabla Control"));
            }

            catch (Exception ex)
            {
                log.Error(string.Format("Error en ControlCheck WCF: {0}", ex.Message));
            }
        }

    }
}
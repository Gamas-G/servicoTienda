﻿namespace DMPMSDV
{
    using System.ServiceModel;

    [ServiceContract]
    public interface IWcfDMPMonitorDV
    {
        [OperationContract]
        bool MonitorDVPorSolicitud();
    }
}
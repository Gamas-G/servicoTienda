﻿namespace DMPMSDV
{
    using System.ServiceProcess;
    static class Program
    {
        static void Main()
        {
            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[]
            {
                new DMPMSDV()
            };
            ServiceBase.Run(ServicesToRun);
        }
    }
}
